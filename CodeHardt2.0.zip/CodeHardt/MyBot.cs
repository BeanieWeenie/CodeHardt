﻿using Discord;
using Discord.Commands;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeHardt
{
    class MyBot
    {

        DiscordClient discord;
        CommandService Commands;
        public MyBot()
        {
            discord = new DiscordClient(x =>
            {
                x.LogLevel = LogSeverity.Info;
                x.LogHandler = Log;
            });

            discord.UsingCommands(x =>
            {
                x.PrefixChar = '!';
                x.AllowMentionPrefix = true;
            });
            Commands = discord.GetService<CommandService>();

            RegisterPicCommand();


            discord.ExecuteAndWait(async () =>
            {
                await discord.Connect("MjY5NTg3NTU0MzY0NDI0MTkz.C1rk_g.ZNx9ncqfoTcN4zekZZ5AK20dwKo", TokenType.Bot);
            });
        }
        private void RegisterPicCommand()
        {

            Commands.CreateCommand("Salty")
                .Do(async (e) =>
                {
                    await e.Channel.SendFile("Photographs/Salt.jpg");
                });
            Commands.CreateCommand("Codehardt")
                .Do(async (e) =>
                {
                    await e.Channel.SendFile("Photographs/BotHardt.png");
                });
            Commands.CreateCommand("Hello")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage("HELLO MY COMRADE!");
                });
            Commands.CreateCommand("Sheild")
                .Do(async (e) =>
                {
                    await e.Channel.SendMessage("Get Behind Me, I Shall Be Your Sheild!");
                    await e.Channel.SendFile("Photographs/BotHardt.png");
                });
            Commands.CreateCommand("Cardboard")
                .Do(async (e) =>
                {
                    await e.Channel.SendFile("Photographs/CarbHardt2.jpg");
                });
            Commands.CreateCommand("President")
            .Do(async (e) =>
               {
                   await e.Channel.SendFile("Photographs/El-Presidente.jpg");
               });
        }
        private void Log(object sender, LogMessageEventArgs e)
        {
            Console.WriteLine(e.Message)

          ;
        }
    }
}

